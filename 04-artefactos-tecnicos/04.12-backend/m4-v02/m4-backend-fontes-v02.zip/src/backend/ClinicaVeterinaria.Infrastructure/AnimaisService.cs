using ClinicaVeterinaria.Application.Exceptions;
using ClinicaVeterinaria.Application.Interfaces;
using ClinicaVeterinaria.Application.Models.Animais;
using ClinicaVeterinaria.Application.Models.Comum;
using ClinicaVeterinaria.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ClinicaVeterinaria.Infrastructure;

public sealed class AnimaisService : IAnimaisService
{
    private const string MensagemAnimalNaoEncontrado =
        "O animal indicado não existe.";

    private const string MensagemAnimalDeOutroCliente =
        "O animal indicado não pertence ao Cliente autenticado.";

    private const string MensagemClienteNaoEncontrado =
        "O cliente indicado não existe.";

    private readonly ClinicaDbContext _db;
    private readonly TimeProvider _relogio;

    public AnimaisService(
        ClinicaDbContext db,
        TimeProvider relogio)
    {
        _db = db;
        _relogio = relogio;
    }

    public async Task<PaginaResultados<ResumoAnimal>> PesquisarAsync(
        PesquisaAnimais filtro)
    {
        ArgumentNullException.ThrowIfNull(filtro);

        var consulta =
            from p in _db.Pacientes.AsNoTracking()
            join c in _db.Clientes.AsNoTracking()
                on p.ClienteId equals c.Id
            join e in _db.Especies.AsNoTracking()
                on p.EspecieId equals e.Id
            select new
            {
                Paciente = p,
                Cliente = c,
                Especie = e.Nome,
                Raca = _db.Racas
                    .Where(r => r.Id == p.RacaId && r.EspecieId == p.EspecieId)
                    .Select(r => r.Nome)
                    .FirstOrDefault(),
            };

        if (filtro.ClienteId.HasValue)
        {
            consulta = consulta.Where(x =>
                x.Paciente.ClienteId == filtro.ClienteId.Value);
        }

        var pesquisa = filtro.Pesquisa?.Trim();

        if (!string.IsNullOrEmpty(pesquisa))
        {
            consulta = consulta.Where(x =>
                x.Paciente.Nome.Contains(pesquisa)
                || x.Cliente.Nome.Contains(pesquisa));
        }

        var especie = filtro.Especie?.Trim();

        if (!string.IsNullOrEmpty(especie))
        {
            consulta = consulta.Where(x =>
                x.Especie == especie);
        }

        var total = await consulta.CountAsync();

        // Em long, como em EP-004: com uma página muito alta, (pagina - 1) * tamanho ultrapassava
        // o limite de int e dava um salto negativo (erro 500). Depois do fim, a página fica vazia.
        var salto = (long)(filtro.Pagina - 1) * filtro.Tamanho;

        List<ResumoAnimal> itens = [];

        if (salto < total)
        {
            var dados = await consulta
                .OrderBy(x => x.Paciente.Nome)
                .ThenBy(x => x.Paciente.Id)
                .Skip((int)salto)
                .Take(filtro.Tamanho)
                .Select(x => new
                {
                    x.Paciente.Id,
                    x.Paciente.Nome,
                    x.Especie,
                    x.Raca,
                    x.Paciente.DataNascimento,
                    x.Paciente.Peso,
                    ClienteId = x.Cliente.Id,
                    ClienteNome = x.Cliente.Nome,
                })
                .ToListAsync();

            itens = dados
                .Select(x => new ResumoAnimal
                {
                    Id = x.Id,
                    Nome = x.Nome,
                    Especie = x.Especie,
                    Raca = x.Raca,
                    IdadeAnos = CalcularIdade(x.DataNascimento),
                    Peso = x.Peso,
                    Cliente = new DonoAnimal
                    {
                        Id = x.ClienteId,
                        Nome = x.ClienteNome,
                    },
                })
                .ToList();
        }

        return new PaginaResultados<ResumoAnimal>
        {
            Itens = itens,
            Pagina = filtro.Pagina,
            Tamanho = filtro.Tamanho,
            Total = total,
        };
    }

    public async Task<DetalheAnimal> ObterAsync(int id)
    {
        var dados = await (
            from p in _db.Pacientes.AsNoTracking()
            join c in _db.Clientes.AsNoTracking()
                on p.ClienteId equals c.Id
            join e in _db.Especies.AsNoTracking()
                on p.EspecieId equals e.Id
            where p.Id == id
            select new
            {
                Paciente = p,
                Cliente = c,
                Especie = e.Nome,
                Raca = _db.Racas
                    .Where(r => r.Id == p.RacaId && r.EspecieId == p.EspecieId)
                    .Select(r => r.Nome)
                    .FirstOrDefault(),
            })
            .FirstOrDefaultAsync()
            ?? throw new NaoEncontradoException(MensagemAnimalNaoEncontrado);

        return new DetalheAnimal
        {
            Id = dados.Paciente.Id,
            Nome = dados.Paciente.Nome,
            Especie = dados.Especie,
            Raca = dados.Raca,
            Sexo = dados.Paciente.Sexo,
            DataNascimento = dados.Paciente.DataNascimento,
            IdadeAnos = CalcularIdade(dados.Paciente.DataNascimento),
            Peso = dados.Paciente.Peso,
            Cliente = new ContactoDonoAnimal
            {
                Id = dados.Cliente.Id,
                Nome = dados.Cliente.Nome,
                Telefone = dados.Cliente.Telefone,
            },
            AtualizadoEm = dados.Paciente.DataUltimaAlteracao,
        };
    }

    public async Task<DetalheAnimal> CriarAsync(DadosAnimal pedido)
    {
        ArgumentNullException.ThrowIfNull(pedido);

        ValidarDadosAdministrativos(pedido);

        var clienteExiste = await _db.Clientes
            .AnyAsync(c => c.Id == pedido.ClienteId);

        if (!clienteExiste)
        {
            throw new NaoEncontradoException(MensagemClienteNaoEncontrado);
        }

        var especie = await _db.Especies
            .FirstOrDefaultAsync(e => e.Nome == pedido.Especie.Trim())
            ?? throw new ValidacaoException("A espécie indicada não existe.");

        int? racaId = null;

        if (!string.IsNullOrWhiteSpace(pedido.Raca))
        {
            var raca = await _db.Racas
                .FirstOrDefaultAsync(r =>
                    r.EspecieId == especie.Id
                    && r.Nome == pedido.Raca.Trim())
                ?? throw new ValidacaoException(
                    "A raça indicada não existe para a espécie selecionada.");

            racaId = raca.Id;
        }

        var agora = Agora();

        var paciente = new Paciente
        {
            ClienteId = pedido.ClienteId,
            Nome = pedido.Nome.Trim(),
            EspecieId = especie.Id,
            RacaId = racaId,
            Sexo = pedido.Sexo,
            DataNascimento = pedido.DataNascimento,
            Peso = pedido.Peso,
            DataRegisto = agora,
        };

        _db.Pacientes.Add(paciente);
        await _db.SaveChangesAsync();

        return await ObterAsync(paciente.Id);
    }

    public async Task<DetalheAnimal> AtualizarAsync(
        int id,
        DadosAnimal pedido)
    {
        ArgumentNullException.ThrowIfNull(pedido);

        var paciente = await _db.Pacientes
            .FirstOrDefaultAsync(p => p.Id == id)
            ?? throw new NaoEncontradoException(MensagemAnimalNaoEncontrado);

        ValidarDadosAdministrativos(pedido);

        var clienteExiste = await _db.Clientes
            .AnyAsync(c => c.Id == pedido.ClienteId);

        if (!clienteExiste)
        {
            throw new NaoEncontradoException(MensagemClienteNaoEncontrado);
        }

        var especie = await _db.Especies
            .FirstOrDefaultAsync(e => e.Nome == pedido.Especie.Trim())
            ?? throw new ValidacaoException("A espécie indicada não existe.");

        int? racaId = null;

        if (!string.IsNullOrWhiteSpace(pedido.Raca))
        {
            var raca = await _db.Racas
                .FirstOrDefaultAsync(r =>
                    r.EspecieId == especie.Id
                    && r.Nome == pedido.Raca.Trim())
                ?? throw new ValidacaoException(
                    "A raça indicada não existe para a espécie selecionada.");

            racaId = raca.Id;
        }

        paciente.ClienteId = pedido.ClienteId;
        paciente.Nome = pedido.Nome.Trim();
        paciente.EspecieId = especie.Id;
        paciente.RacaId = racaId;
        paciente.Sexo = pedido.Sexo;
        paciente.DataNascimento = pedido.DataNascimento;
        paciente.Peso = pedido.Peso;
        paciente.DataUltimaAlteracao = Agora();

        await _db.SaveChangesAsync();

        return await ObterAsync(paciente.Id);
    }

    public async Task<IReadOnlyList<ResumoMeuAnimal>> ListarDoClienteAsync(int clienteId)
    {
        var dados = await (
            from p in _db.Pacientes.AsNoTracking()
            join e in _db.Especies.AsNoTracking()
                on p.EspecieId equals e.Id
            where p.ClienteId == clienteId
            orderby p.Nome, p.Id
            select new
            {
                p.Id,
                p.Nome,
                Especie = e.Nome,
                Raca = _db.Racas
                    .Where(r => r.Id == p.RacaId && r.EspecieId == p.EspecieId)
                    .Select(r => r.Nome)
                    .FirstOrDefault(),
                p.DataNascimento,
                p.Peso,
            })
            .ToListAsync();

        return dados
            .Select(x => new ResumoMeuAnimal
            {
                Id = x.Id,
                Nome = x.Nome,
                Especie = x.Especie,
                Raca = x.Raca,
                IdadeAnos = CalcularIdade(x.DataNascimento),
                Peso = x.Peso,
            })
            .ToList();
    }

    public async Task<DetalheMeuAnimal> ObterDoClienteAsync(int clienteId, int animalId)
    {
        var dados = await (
            from p in _db.Pacientes.AsNoTracking()
            join e in _db.Especies.AsNoTracking()
                on p.EspecieId equals e.Id
            where p.Id == animalId
            select new
            {
                p.Id,
                p.ClienteId,
                p.Nome,
                Especie = e.Nome,
                Raca = _db.Racas
                    .Where(r => r.Id == p.RacaId && r.EspecieId == p.EspecieId)
                    .Select(r => r.Nome)
                    .FirstOrDefault(),
                p.Sexo,
                p.DataNascimento,
                p.Peso,
            })
            .FirstOrDefaultAsync()
            ?? throw new NaoEncontradoException(MensagemAnimalNaoEncontrado);

        // O dono é comparado com o Cliente do token; nenhum dado do animal
        // é devolvido quando pertence a outro Cliente (RNF002).
        if (dados.ClienteId != clienteId)
        {
            throw new ForbiddenException(MensagemAnimalDeOutroCliente);
        }

        return new DetalheMeuAnimal
        {
            Id = dados.Id,
            Nome = dados.Nome,
            Especie = dados.Especie,
            Raca = dados.Raca,
            Sexo = dados.Sexo,
            DataNascimento = dados.DataNascimento,
            IdadeAnos = CalcularIdade(dados.DataNascimento),
            Peso = dados.Peso,
        };
    }

    private int? CalcularIdade(DateOnly? dataNascimento)
    {
        if (!dataNascimento.HasValue)
        {
            return null;
        }

        var hoje = DateOnly.FromDateTime(_relogio.GetUtcNow().UtcDateTime);
        var nascimento = dataNascimento.Value;

        var idade = hoje.Year - nascimento.Year;

        if (nascimento > hoje.AddYears(-idade))
        {
            idade--;
        }

        return idade;
    }

    private void ValidarDadosAdministrativos(DadosAnimal pedido)
    {
        if (pedido.Peso.HasValue && pedido.Peso.Value <= 0)
        {
            throw new ValidacaoException("O peso deve ser superior a 0.");
        }

        if (pedido.DataNascimento.HasValue)
        {
            var hoje = DateOnly.FromDateTime(
                _relogio.GetUtcNow().UtcDateTime);

            if (pedido.DataNascimento.Value > hoje)
            {
                throw new ValidacaoException(
                    "A data de nascimento não pode ser futura.");
            }
        }
    }

    private DateTime Agora()
    {
        var agora = _relogio.GetUtcNow().UtcDateTime;

        return new DateTime(
            agora.Ticks - (agora.Ticks % TimeSpan.TicksPerSecond),
            DateTimeKind.Utc);
    }
}
