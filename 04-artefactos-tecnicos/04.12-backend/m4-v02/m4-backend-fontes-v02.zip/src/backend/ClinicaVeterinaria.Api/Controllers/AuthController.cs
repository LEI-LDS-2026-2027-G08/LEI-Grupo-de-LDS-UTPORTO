using ClinicaVeterinaria.Api.DTOs.Auth;
using ClinicaVeterinaria.Api.Mapeamento;
using ClinicaVeterinaria.Application.Exceptions;
using ClinicaVeterinaria.Application.Interfaces;
using ClinicaVeterinaria.Application.Seguranca;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaVeterinaria.Api.Controllers;

[ApiController]
[Route("auth")]
[Produces("application/json")]
public sealed class AuthController : ControllerBase
{
    private readonly IAuthService _authService;

    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    /// <summary>EP-001 — Iniciar sessão (todos os perfis).</summary>
    /// <response code="200">Credenciais válidas de conta ativa; devolve o JWT (HS256, 8 horas).</response>
    /// <response code="400">E-mail ou palavra-passe em falta.</response>
    /// <response code="401">Credenciais incorretas.</response>
    /// <response code="403">Conta bloqueada.</response>
    [HttpPost("login")]
    [AllowAnonymous]
    [ProducesResponseType<LoginResponseDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<LoginResponseDto>> Login(LoginRequestDto pedido)
    {
        var resultado = await _authService.LoginAsync(pedido.ParaModelo());
        return Ok(resultado.ParaDto());
    }

    /// <summary>EP-002 — Terminar sessão (todos os perfis).</summary>
    /// <remarks>
    /// Revoga o token usado no pedido (o seu <c>jti</c>) até à expiração original (RF003).
    /// Depois disso, qualquer pedido com esse token recebe 401, também depois de a API reiniciar.
    /// </remarks>
    /// <response code="204">Sessão terminada; o token deixa de permitir acesso autenticado.</response>
    /// <response code="401">Token ausente, inválido, expirado ou já revogado.</response>
    [HttpPost("logout")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> TerminarSessao()
    {
        var utilizadorId = User.ObterUtilizadorId();
        var jti = User.ObterJti();
        var expiraEm = User.ObterExpiracao();

        if (utilizadorId is null || string.IsNullOrEmpty(jti) || expiraEm is null)
        {
            throw new NaoAutenticadoException("O token não contém as claims obrigatórias.");
        }

        await _authService.TerminarSessaoAsync(utilizadorId.Value, jti, expiraEm.Value);

        return NoContent();
    }

    /// <summary>EP-003 — Consultar utilizador autenticado (todos os perfis).</summary>
    /// <response code="200">Identidade e perfil atual do utilizador do token.</response>
    /// <response code="401">Token ausente, inválido, expirado ou revogado.</response>
    [HttpGet("me")]
    [Authorize]
    [ProducesResponseType<UtilizadorAutenticadoDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UtilizadorAutenticadoDto>> ObterUtilizadorAutenticado()
    {
        var utilizadorId = User.ObterUtilizadorId()
            ?? throw new NaoAutenticadoException("O token não identifica o utilizador.");

        var resultado = await _authService.ObterAutenticadoAsync(utilizadorId);
        return Ok(resultado.ParaDto());
    }
}
