using System.ComponentModel.DataAnnotations;
using ClinicaVeterinaria.Application.Validacao;

namespace ClinicaVeterinaria.Api.DTOs.Clientes;

/// <summary>Pedido de EP-014 (PUT /clientes/{id}); base do pedido de EP-013.</summary>
public class UpdateClienteDto
{
    [Required(AllowEmptyStrings = false, ErrorMessage = "O nome é obrigatório.")]
    [MaxLength(150, ErrorMessage = "O nome não pode ter mais de 150 caracteres.")]
    public string Nome { get; set; } = string.Empty;

    [NifValido]
    public string? Nif { get; set; }

    [Required(AllowEmptyStrings = false, ErrorMessage = "O telefone é obrigatório.")]

    // 9 a 20 caracteres no total (coluna Telefone NVARCHAR(20)), contando o + e os espaços.
    [RegularExpression(@"^(?=.{9,20}$)\+?[0-9 ]+$",
        ErrorMessage = "O telefone deve ter entre 9 e 20 caracteres: dígitos, espaços e, opcionalmente, o indicativo + no início.")]
    public string Telefone { get; set; } = string.Empty;

    [Required(AllowEmptyStrings = false, ErrorMessage = "O e-mail é obrigatório.")]

    // Regra R-EMAIL (I028), a mesma das contas de funcionário: o [EmailAddress] do .NET aceitava "joao@mail".
    [EmailValido]
    [MaxLength(256, ErrorMessage = "O e-mail não pode ter mais de 256 caracteres.")]
    public string Email { get; set; } = string.Empty;

    [MaxLength(250, ErrorMessage = "A morada não pode ter mais de 250 caracteres.")]
    public string? Morada { get; set; }
}
