namespace ClinicaVeterinaria.Api.DTOs.Utilizadores;

public class UtilizadorListItemDto
{
    public int Id { get; set; }

    public string Nome { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string Perfil { get; set; } = string.Empty;

    public string Estado { get; set; } = string.Empty;

    public bool PodeRegistarApoio { get; set; }
}
